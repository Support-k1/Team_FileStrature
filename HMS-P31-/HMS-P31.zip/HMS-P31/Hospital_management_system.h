#pragma once
#include<iostream>
#include<cstring>
#include<fstream>
using namespace std;

// Abstract Classes  Hospital_management_system and Pure Virtual Functions
class  Hospital_management_system{ 


public:
    Hospital_management_system()=default;
    virtual  void create_record()=0;
    virtual  void Search()=0;
    virtual  void Update_record()=0;
    virtual  void Binary_search()=0;
    virtual  void delete_record()=0;
    virtual  void display_record()=0;
    virtual  void Help()=0;
    virtual  void Exit()=0;
    ~Hospital_management_system()=default;

};

//class patient derived class form Hospital_management_system
class patient: public Hospital_management_system{

private:

 char patient_name[20];//variable of type char, it will be for example. Char patient_name[50]
 long  id;           //variable of type long, it will be for example. String id
 int Age;              //variable of type int, it will be for example. Int age
 string Address;       //variable of type string, it will be for example. String address
 char Status[15];        //variable of type char, it will be for example. String status

public:
        
      void create_record() override;
      void Search() override{};
      void Update_record() override{};
      void Binary_search() override{};
      void delete_record() override{};
      void display_record() override{};
      void Help() override{};
      void Exit() override{};

      void set_patient_name(char *name) {strcpy_s(patient_name, name);}
      void set_patient_id(long id) { id = id;}
      void set_patient_age(int age) {Age = age;}
      void set_patient_Address(string Addres) { this->Address= Address; }
      void set_patient_Status(char* Status) { strcpy_s(this->Status, Status); }

      char* get_patient_name() { return patient_name; }
      long get_patient_id() {     return id; }
      int get_patient_age() {  return Age; }
      string get_patient_Address() { return Address; }
      char* get_patient_Status() { return Status;}
      


};
