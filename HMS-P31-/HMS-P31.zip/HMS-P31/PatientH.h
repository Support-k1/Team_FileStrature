#pragma once
#include "Hospital_management_system.h"
//////////////create patient record/////////////
char byte;
patient getP_info() {
    patient obj;
    char name[20], Status[15];
    long  id; int age; string Address;
    cout << "Enter patient name \n";
    cin.getline(name, 20); cin.ignore();
    cout << "Enter patient id \n";
    cin >> id;
    cout << "Enter patient Status \n";
    cout << "Enter patient age \n";
    cin >> age;
    cout << "Enter patient Address \n";
    getline(cin, Address);
    cin.ignore();
    obj.set_patient_name(name);
    obj.set_patient_id(id);
    obj.set_patient_Status("Normel");
    obj.set_patient_age(20);
    obj.set_patient_Address(Address);

    return obj;
}


void patient::create_record() {

    patient obj = getP_info();
    fstream file;
    file.open("patient_details.txt", ios::binary | ios::app);
    short header = -1;
    file.seekg(0, ios::end);
    int file_size = file.tellg();

    if (!file_size) {
        file.seekp(0, ios::beg);
        file.put('*');
        file.write((char*)&header, sizeof(short));
    }

    //get Lenght
    short varLenghtrecorde = 2 + 20 + 4 + (obj.get_patient_Address().size()) + sizeof(long) + 15;

    ///read the header
    file.seekg(0, ios::beg);
    file >> byte;
    file.read((char*)&header, sizeof(short));
    file.clear();

    if (header == -1) {
        file.seekp(0, ios::end);
        short tempF = varLenghtrecorde;
        file.write((char*)&tempF, sizeof(short));

        tempF = obj.get_patient_id();
        file.write((char*)&tempF, sizeof(short));
        file.put('|');

        file.write(&*obj.get_patient_name(), 20);
        file.put('|');

        file << obj.get_patient_age();
        file.put('|');

        const char* tempS = obj.get_patient_Address().c_str();
        file << obj.get_patient_Address();

        file.write(tempS, 20);
        file.put('|');


        file.write(&*obj.get_patient_Status(), 15);
        file.put('|');

        file.close();

    }
}

