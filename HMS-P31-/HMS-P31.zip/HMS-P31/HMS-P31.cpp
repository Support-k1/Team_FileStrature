#include"PatientH.h"
using namespace std;
int main() {
	patient p1;
	p1.create_record();



}